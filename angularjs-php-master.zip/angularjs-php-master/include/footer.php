<!-- end #page -->
        <div id="footer">
            <p>Copyright (c) 2011 Sitename.com. All rights reserved. Design by <a href="http://www.freecsstemplates.org/">FCT</a>.</p>
        </div>
        <!-- end #footer -->
    </div>
</div>
</body>
</html>
