<?php
  $link=mysql_connect('localhost','root','123456');
  mysql_select_db('angluar_blog',$link);
 
?>
